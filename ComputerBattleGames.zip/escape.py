import random
import os
import time
import main_menu

def escape_intro():
    print(r""" 
    ___________                                 ._.
    ╲_   _____╱ ______ ____ _____  ______   ____│ │
    │    __)_ ╱  ___╱╱ ___╲╲__  ╲ ╲____ ╲_╱ __ ╲ │
    │        ╲╲___ ╲╲  ╲___ ╱ __ ╲│  │_> >  ___╱╲│
    ╱_______  ╱____  >╲___  >____  ╱   __╱ ╲___  >_
            ╲╱     ╲╱     ╲╱     ╲╱│__│        ╲╱╲╱
    """)
    time.sleep(2)

    print("""

    The Robots have caught you, taken your weapons and locked you up.
    Suddenly you remember you still have your sonar wristwatch, which can be
    tuned to produce sounds ofany frequency. If you can only find the resonant
    frequency of your Robot guards, they should vibrate so much they fall apart.
    You must be careful not to use frequencies that are too low or the building
    wll vibrate and cllapse on top ofyou. If you go too high, you will get such a
    terrible headache you will have to give up.

    Can you escape the horrors of the Robot prison? (Look carefuUy at the
    program for a clue to the range offrequencies to try.)""")

    time.sleep(6)

    os.system('cls||clear')
    
def escape_game():
    robot_frequency = random.randint(100, 1000) 
    # print(robot_frequency) # (Hidden for testing, uncomment if you need it!)

    chances = 10
    won = False

    os.system('cls||clear') # Clear the screen again so the game board is clean
    print("--- ROBOT PRISON ESCAPE ---")

    while chances > 0:
        if chances == 1:
            print("\nBe careful! You only have one chance left!")
        else:
            print(f"\nYou have {chances} chances left.")
            
        try:
            player_guess = int(input("Enter a frequency to try (100 - 1000 Hz): "))
        except ValueError:
            print("Invalid input! Please enter a whole number.")
            continue
        
        # Check if guess is within bounds
        if player_guess < 100 or player_guess > 1000:
            print("That frequency is out of range! Stay between 100 and 1000 Hz.")
            continue

        # Win condition (within 5 Hz margin)
        if abs(robot_frequency - player_guess) <= 5: 
            print(f"\nSUCCESS! The actual frequency was {robot_frequency} Hz.")
            print("Congratulations! You found the resonant frequency and escaped the prison!")
            won = True
            break
        
        # Feedback logic
        elif player_guess < robot_frequency:
            print("Too Low! The building is starting to vibrate. You lose a chance.")
        elif player_guess > robot_frequency:
            print("Too High! You get a terrible headache. You lose a chance.")
            
        chances -= 1
    
    # MOVED OUTSIDE THE LOOP: Triggers only if the loop ends and won is still False
    if not won:
        print(f"\nGame over! The frequency was {robot_frequency} Hz. You failed to escape the prison.")

if __name__ == "__main__":
    escape_intro()
    while True:
        escape_game()  
        
        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break 
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break