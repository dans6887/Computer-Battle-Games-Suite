import os
import random
import string
import time
import main_menu

def vital_message_intro():
    print("Welcome to VITAL MESSAGE!")
    print("You must send a vital message to the command center.")
    print("But be careful, the enemy is listening!")
    print()
    time.sleep(2)


def begin_game():
    os.system('cls||clear') 

    print("VITAL MESSAGE")
    print()

    while True:
        try:
            difficulty = int(input("How Difficult? (4-10): "))
            if 4 <= difficulty <= 10:
                break
            print("Please enter a number between 4 and 10.")
        except ValueError:
            print("Invalid input. Please enter a number.")

    m = "".join(random.choice(string.ascii_uppercase) for _ in range(difficulty))

    os.system('cls||clear') 
    print("SEND THIS MESSAGE: \n")
    print(m)

    time.sleep(5) 
    os.system('cls||clear') 

    answer = input("Enter your answer then press [ENTER]: ").upper()

    if answer == m:
        print("Message Correct...")
        time.sleep(2)
        print("The robot war is over.")
    else:
        print("Message incorrect...")
        time.sleep(2)
        print("The robot invasion has started!")

if __name__ == "__main__":
    vital_message_intro()
    while True:
        begin_game()  
        
        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break