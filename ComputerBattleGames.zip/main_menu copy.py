import os
import sys
import time



# Custom import errors can be caught gracefully if a file is missing
loaded_games = {}
try:
    import vital_message
    loaded_games['1'] = vital_message
except ImportError:
    print("Warning: Could not import vital_message. Check your folder structure.")

try:
    import secret_weapon
    loaded_games['2'] = secret_weapon
except ImportError:
    print("Warning: Could not import secret_weapon. Check your folder structure.")

try:
    import desert_tank_battle
    loaded_games['3'] = desert_tank_battle
except ImportError:
    print("Warning: Could not import desert_tank_battle. Check your folder structure.")

try: 
    import battle_at_traitors_castle
    loaded_games['4'] = battle_at_traitors_castle
except ImportError:
    print("Warning: Could not import battle_at_traitors_castle. Check your folder structure.")

try:
    import escape
    loaded_games['5'] = escape
except ImportError:
    print("Warning: Could not import escape. Check your folder structure.")

try:
    import pirate_dogfight    
    loaded_games['6'] = pirate_dogfight
except ImportError:
    print("Warning: Could not import pirate_dogfight. Check your folder structure.")

try: 
    import shootout
    loaded_games['7'] = shootout
except ImportError:
    print("Warning: Could not import shootout. Check your folder structure.")

try:
    import supersonic_bomber
    loaded_games['8'] = supersonic_bomber
except ImportError:
    print("Warning: Could not import supersonic_bomber. Check your folder structure.")
    
try:
    import robot_invaders
    loaded_games['9'] = robot_invaders
except ImportError:
    print("Warning: Could not import robot_invaders. Check your folder structure.")


def intro():
    print(r"""
 ▄████████  ▄██████▄    ▄▄▄▄███▄▄▄▄      ▄███████▄ ███    █▄      ███        ▄████████    ▄████████      
███    ███ ███    ███ ▄██▀▀▀███▀▀▀██▄    ███    ███ ███    ███ ▀█████████▄   ███    ███   ███    ███      
███    █▀  ███    ███ ███   ███   ███    ███    ███ ███    ███    ▀███▀▀██   ███    █▀    ███    ███      
███        ███    ███ ███   ███   ███    ███    ███ ███    ███     ███   ▀  ▄███▄▄▄      ▄███▄▄▄▄██▀      
███        ███    ███ ███   ███   ███    ███    ███ ███    ███     ███      ▀▀███▀▀▀      ▀▀███▀▀▀▀▀        
███    █▄  ███    ███ ███   ███   ███    ███    ███ ███    ███     ███         ███    █▄  ▀███████████      
███    ███ ███    ███ ███   ███   ███    ███    ███ ███    ███     ███         ███    ███   ███    ███      
████████▀   ▀██████▀   ▀█   ███   █▀     ▄████▀      ████████▀     ▄████▀      ██████████   ███    ███      
                                                                                          ███    ███      
            ▀█████████▄    ▄████████     ███         ███     ▄█          ▄████████                        
             ███    ███   ███    ███ ▀█████████▄ ▀█████████▄ ███         ███    ███                        
             ███    ███   ███    ███    ▀███▀▀██    ▀███▀▀██ ███         ███    █▀                         
            ▄███▄▄▄██▀    ███    ███     ███   ▀     ███   ▀ ███        ▄███▄▄▄                            
           ▀▀███▀▀▀██▄  ▀███████████     ███         ███     ███        ▀▀███▀▀▀                            
             ███    ██▄   ███    ███     ███         ███     ███         ███    █▄                         
             ███    ███   ███    ███     ███         ███     ███▌    ▄   ███    ███                        
           ▄█████████▀    ███    █▀     ▄████▀      ▄████▀   █████▄▄██   ██████████                        
                                                             ▀                                             
                  ▄██████▄     ▄████████  ▄▄▄▄███▄▄▄▄     ▄████████    ▄████████                       
                 ███    ███   ███    ███ ▄██▀▀▀███▀▀▀██▄   ███    ███   ███    ███                       
                 ███    █▀    ███    ███ ███   ███   ███   ███    █▀    ███    █▀                        
                ▄███          ███    ███ ███   ███   ███  ▄███▄▄▄        ███                             
               ▀▀███ ████▄  ▀███████████ ███   ███   ███ ▀▀███▀▀▀      ▀███████████                       
                 ███    ███   ███    ███ ███   ███   ███   ███    █▄            ███                       
                 ███    ███   ███    ███ ███   ███   ███   ███    ███     ▄█    ███                       
                 ████████▀    ███    █▀   ▀█   ███   █▀    ██████████  ▄████████▀                        
                                                                                                       
 """)

def menu():
    while True:
        print("\n=== Computer Battle Games ===")
        print("Please select a game to play:")
        print("1. Vital Message")
        print("2. Secret Weapon")
        print("3. Desert Tank Battle")
        print("4. Battle At Traitor's Castle")
        print("5. Escape")                  
        print("6. Pirate Dogfight")
        print("7. Shootout")
        print("8. Supersonic Bomber")
        print("9. Robot Invaders")
        print("10. Exit")
        print("=============================")
        
        choice = input("Enter the number of your choice: ")
        
        if choice == '1':
            if '1' in loaded_games:
                print("Loading Vital Message...")
                time.sleep(2)
                loaded_games['1'].vital_message_intro()
                while True:
                    try:
                        loaded_games['1'].begin_game()
                        time.sleep(2)
                        choice = input("\nPlay again? (y/n): ").strip().lower()
                        if choice == 'n':
                            menu()
                        elif choice != 'y':
                            print("Invalid input. Returning to main menu...")
                            time.sleep(2)
                            menu()
                            break
                    except Exception as e:
                        print(f"An error occurred: {e}")
                        break
            
            else:
                print("Vital Message not found")
        elif choice == '2':
            if '2' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['2'].secret_weapon_intro()
                while True:
                    try:
                        loaded_games['2'].secret_weapon_game()
                        time.sleep(2)
                        choice = input("\nPlay again? (y/n): ").strip().lower()
                        if choice == 'n':
                            menu()
                        elif choice != 'y':
                            print("Invalid input. Returning to main menu...")
                            time.sleep(2)
                            menu()
                            break
                    except Exception as e:
                        print(f"An error occurred: {e}")
                        break
            else:
                print("Secret Weapon not found")
        elif choice == '3':
            if '3' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['3'].desert_tank_battle_intro()
                while True:
                    try:
                        loaded_games['3'].desert_tank_battle_game()
                        time.sleep(2)
                        choice = input("\nPlay again? (y/n): ").strip().lower()
                        if choice == 'n':
                            menu()
                        elif choice != 'y':
                            print("Invalid input. Returning to main menu...")
                            time.sleep(2)
                            menu()
                            break
                    except Exception as e:
                        print(f"An error occurred: {e}")
                        break
            else:
                print("Desert Tank Battle not found")
        elif choice == '4':
            if '4' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['4'].traitor_castle_intro()
                while True:
                    try:
                        loaded_games['4'].begin_battle()
                        time.sleep(2)
                        choice = input("\nPlay again? (y/n): ").strip().lower()
                        if choice == 'n':
                            menu()
                        elif choice != 'y':
                            print("Invalid input. Returning to main menu...")
                            time.sleep(2)
                            menu()
                            break
                    except Exception as e:
                        print(f"An error occurred: {e}")
                        break
            else:
                print("Battle At Traitor's Castle not found")
        elif choice == '5':
            if '5' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['5'].escape_intro()
                loaded_games['5'].escape_game()
            else:
                print("Escape not found")
        elif choice == '6':
            if '6' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['6'].dogfight_intro()
                loaded_games['6'].pirate_dogfight()
            else:
                print("Pirate Dogfight not found")
        elif choice == '7':
            if '7' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['7'].shootout_intro()
                loaded_games['7'].shootout_game()
                
            else:
                print("Shootout not found")
        elif choice == '8':
            if '8' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['8'].supersonic_bomber_intro()
                loaded_games['8'].supersonic_bomber_game()
            else:
                print("Supersonic Bomber not found")
        elif choice == '9':
            if '9' in loaded_games:
                print("loading game...")
                time.sleep(2)
                loaded_games['9'].robot_invaders_intro()
                loaded_games['9'].robot_invaders_game()
            else:
                print("Robot Invaders not found")
        elif choice == '10':
            print("Thank you for playing!")
            sys.exit()
        else:
            print("Invalid choice. Please try again.")
            time.sleep(1)


if __name__ == "__main__":
    try:
        intro()
        menu()
    except KeyboardInterrupt:
        print("\nExiting Menu. Goodbye!")
        sys.exit()