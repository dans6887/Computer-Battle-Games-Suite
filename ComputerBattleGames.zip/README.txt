In 1982 usborn Computer Programs published Computer Battlegames. Written by Daniel lsaaman and Jenny Tyler, the book was designed to teach programming for 
microcomputers such as the ZX81, ZX Spectrum,BBC,VIC20,TRS-80 and Pet and Apple micros. The games were very simple and taught aspiring programmers 
the fundamentals of using the BASIC coding language. 

A pdf copy of the book can be downloaded for from colorcomputerarchive.com at the followng link. 
https://colorcomputerarchive.com/repo/Documents/Books/Computer%20Battlegames%20(Usborne%20Publishing).pdf


How to run the games.
1. Unzip folder
2. Start the main_menu.py script
3. Follow the on-screen prompts.
4. Enjoy!
5. Feel free to edit, expand, mod the games however you like.