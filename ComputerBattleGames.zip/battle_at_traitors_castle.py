import os
import time
import keyboard
import random
import main_menu

def traitor_castle_intro():
    print(r"""
    
                                                               
_-_ _,,           ,    ,  ,,                               
   -/  )    _    ||   ||  ||                               
  ~||_<    < \, =||= =||= ||  _-_                          
   || \\   /-||  ||   ||  || || \\                         
   ,/--|| (( ||  ||   ||  || ||/                           
  _--_-'   \/\\  \\,  \\, \\ \\,/                          
 (                                                         
                                                           
              ,                                            
        _    ||                                            
       < \, =||=                                           
       /-||  ||                                            
      (( ||  ||                                            
       \/\\  \\,                                           
                                                           
             ___                                           
            -   ---___-                  ,                 
               (' ||            _    '  ||                 
              ((  ||    ,._-_  < \, \\ =||=  /'\\ ,._-_    
             ((   ||     ||    /-|| ||  ||  || ||  ||      
              (( //      ||   (( || ||  ||  || ||  ||      
                -____-   \\,   \/\\ \\  \\, \\,/   \\,     
                                                           
                                                           
                          ,- _~.               ,  ,,       
                         (' /|     _          ||  ||       
                        ((  ||    < \,  _-_, =||= ||  _-_  
                        ((  ||    /-|| ||_.   ||  || || \\ 
                         ( / |   (( ||  ~ ||  ||  || ||/   
                          -____-  \/\\ ,-_-   \\, \\ \\,/  
          
    """)


    print("""

    The King is waging a fierce and bloody battle against his deadliest enemy – the Traitor Baron. 
    You are one of the King’s crack bowmen and at this very moment you are crouching behind the bushes outside the Baron’s Castle, 
    shooting at his men as they lift their heads above the battlements.

    Your computer will print a row containing eight dots and an O. 
    The number keys 1 to 9 correspond to the position of the O in the row. 
    You have a short time to press the correct key, and hit the O, before it disappears.

    How many of the Baron’s men can you hit?

    """)

    time.sleep(5)
    os.system('cls||clear') 
    
def begin_battle():
 
    player_score = 0
    rounds = 10
    
    target_string = ""
    
    for i in range(rounds):
        target_position = random.randint(1, 9)
        target_string = "." * (target_position - 1) + "O" + "." * (9 - target_position)
        print(target_string)
        
        start_time = time.time()
        while time.time() - start_time < 3: # player has 3 seconds to hit the target
            if keyboard.is_pressed(str(target_position)):
                player_score += 1
                print("Hit!")
                break
        else:
            print("Miss!")
    
    print(f"Game Over! Your score is: {player_score}")


if __name__ == "__main__":
    # intro_function_here()
    traitor_castle_intro()
    while True:
        # game_function_here()  
        begin_battle()
        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break