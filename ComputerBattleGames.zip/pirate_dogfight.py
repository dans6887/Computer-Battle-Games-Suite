import os
import time
import random
import main_menu

def dogfight_intro():
    print(r"""
       
        __________ .__                  __                     
        \______   \|__|_______ _____  _/  |_   ____            
         |     ___/|  |\_  __ \\__  \ \   __\_/ __ \           
         |    |    |  | |  | \/ / __ \_|  |  \  ___/           
         |____|    |__| |__|   (____  /|__|   \___  >          
                                    \/            \/           
                                                               
________             ____    _____ .__    ____  .__      __    
\______ \    ____   / ___\ _/ ____\|__|  / ___\ |  |__ _/  |_  
 |    |  \  /  _ \ / /_/  >\   __\ |  | / /_/  >|  |  \\   __\ 
 |    `   \(  <_> )\___  /  |  |   |  | \___  / |   Y  \|  |   
/_______  / \____//_____/   |__|   |__|/_____/  |___|  /|__|   
        \/                                           \/        
                                                               
    
    """)

    time.sleep(2)

    print("""It's you against the Sky Pirate. He moves ahead, you accelerate-He
    drops behind, you slow down. You must try to get level with him andthen
    you can fire, hoping that he won't be able to fire and hit youfirst.
    Use the letter keys A to accelerate, D to decelerate and F to fire. Your
    computer will tell you your speed and position relative to the pirate. You
    will need to be ready to press the appropriate keys as soon as youpress
    RUN. Keep pressing A and D until you get level and thenfire""")

    time.sleep(4)
    os.system('cls' if os.name == 'nt' else 'clear')
    
def pirate_dogfight():
    # Game Variables
    player_position = 0
    pirate_position = random.randint(20, 40) # Pirate starts ahead

    player_speed = 5
    pirate_speed = 5

    pirate_health = 100

    # Main Game Loop
    while pirate_health > 0:
        # 1. Update positions based on speeds
        player_position += player_speed
        pirate_position += pirate_speed
        
        # Calculate relative distance
        distance = pirate_position - player_position
        
        print("\n" + "="*40)
        print(f"Pirate Health: {pirate_health}%")
        print(f"Your Speed: {player_speed} mach | Pirate Speed: {pirate_speed} mach")
        
        if distance > 0:
            print(f"The pirate is {distance} meters AHEAD of you.")
        elif distance < 0:
            print(f"The pirate is {abs(distance)} meters BEHIND you.")
            
        # 2. Check Firing Position FIRST (Within 3 meters)
        if abs(distance) <= 3:
            print("\n🎯 LOCK ON ACQUIRED! You are in position to fire!")
            shoot_action = input("Press 'F' to fire, or any other key to maintain pursuit: ").lower()
            
            if shoot_action == 'f':
                if random.random() < 0.6:  # 60% chance to hit
                    damage = random.randint(25, 45)
                    pirate_health -= damage
                    print(f"💥 DIRECT HIT! You dealt {damage} damage to the Sky Pirate!")
                else:
                    print("💨 Missed! The pirate pulled an evasive maneuver!")
                    
                # Pirate panics and changes speed after being shot at
                pirate_speed = random.randint(3, 8)
                time.sleep(2)
                
                if pirate_health <= 0:
                    break # Break out of loop immediately if dead
                continue # Skip normal input to recalculate positions

        # 3. Normal Movement Input (if not firing/after missing)
        action = input("\nPress [A] to accelerate, [D] to decelerate, [Enter] to hold speed: ").lower()
        if action == 'a':
            player_speed += 1
            print(f"Increasing speed to {player_speed}.")
        elif action == 'd':
            if player_speed > 1:
                player_speed -= 1
                print(f"Decreasing speed to {player_speed}.")
            else:
                print("You are already at minimum speed!")
                
        # Pirate organically shifts speeds slightly over time
        pirate_speed += random.choice([-1, 0, 1])
        pirate_speed = max(2, min(pirate_speed, 9)) # Keep pirate speed reasonable
        
        time.sleep(1)
        os.system('cls' if os.name == 'nt' else 'clear')

    print("\n🏆 Congratulations! The Sky Pirate's ship goes down in flames. You win!")
    
if __name__ == "__main__":
    # intro_function_here()
    dogfight_intro()
    while True:
        pirate_dogfight()
        # game_function_here()  
        
        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break