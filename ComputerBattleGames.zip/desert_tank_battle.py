import os
import time
import random
import math
import main_menu


def desert_tank_battle_intro():
    print("""
    ____  _____ ____  _____ ____ _____   _____  _    _   _ _  __  ____    _  _____ _____ _     _____ 
    |  _ \| ____/ ___|| ____|  _ \_   _| |_   _|/ \  | \ | | |/ / | __ )  / \|_   _|_   _| |   | ____|
    | | | |  _| \___ \|  _| | |_) || |     | | / _ \ |  \| | ' /  |  _ \ / _ \ | |   | | | |   |  _|  
    | |_| | |___ ___) | |___|  _ < | |     | |/ ___ \| |\  | . \  | |_) / ___ \| |   | | | |___| |___ 
    |____/|_____|____/|_____|_| \_\|_|     |_/_/   \_\_| \_|_|\_\ |____/_/   \_\_|   |_| |_____|_____|
                                                                                                    
    \n""")
    
    time.sleep(2)
    print("""
    The last major stronghold of Robot forces outside the U.R.S* is hidden in ancient castle ruins in the middle of the desert. \n
    A fleet of desert hovertanks has been sent to destroy it and you are the commander. \n
    Your tank controls the five remaining missiles.\n
    """)
    
    time.sleep(5)
    
    print("""
    You must assess carefully the direction and elevation before you launch each one. \n
    Your computer will ask you for a direction angle between -90° (extreme left) and +90° (extreme right) \n
    and an elevation angle between 0° (along the ground) and 90° (straight up in the air). \n
    The elevation determines the distance the missile will travel.\n""")
    
    time.sleep(5)
    
    print("""
    Is your aim good enough to destroy the robot stronghold? \n
    Good luck, commander!\n
    """)
    
    time.sleep(5)
    os.system('cls||clear') #clears the screen before the game starts

def desert_tank_battle_game ():
    
    
    #determine direction and elevationof the target
    target_direction = random.uniform(-90, 90)
    target_distance = random.uniform(0, 100) #distance in meters
    
    chances = 10
    print(f"You have {chances} missiles to destroy the robot stronghold. Good luck, commander!")
    while chances > 0:
        print(f"\nMissiles remaining: {chances}")
    #user enters their guess for direction and elevation
        cannon_direction = float(input("Enter the direction angle for your missile (-90 to 90): "))
        cannon_elevation = float(input("Enter the elevation angle for your missile (0 to 90): "))
        
        #calculate the distance the missile will travel based on the elevation angle
        missile_distance = target_distance * math.sin(math.radians(cannon_elevation))
        chances -= 1
    
        if abs(cannon_direction - target_direction) <= 2 and abs(missile_distance - target_distance) <= 2:
            print("Direct hit! You destroyed the robot stronghold!")
            break
        elif cannon_direction < target_direction:
            print("Your missile went to the left of the target.")
        elif cannon_direction > target_direction:
            print("Your missile went to the right of the target.")
        if missile_distance < target_distance:
            print("Your missile fell short of the target.")
        elif missile_distance > target_distance:
            print("Your missile overshot the target.")
        
    if chances == 0:
        print("You have used all your missiles. The robot stronghold remains intact. You lose!")
        print(f"The target was at direction {target_direction:.2f}° and distance {target_distance:.2f} meters.")
    
if __name__ == "__main__":
    # intro_function_here()
    desert_tank_battle_intro()
    while True:
        # game_function_here()  
        desert_tank_battle_game()

        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break