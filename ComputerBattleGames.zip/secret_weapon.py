import time, random, msvcrt
import main_menu
import os
def secret_weapon_intro():
    print(r"""\033[32m
       
       
 ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄ 
▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌
▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀▀▀  ▀▀▀▀█░█▀▀▀▀ 
▐░▌          ▐░▌          ▐░▌          ▐░▌       ▐░▌▐░▌               ▐░▌     
▐░█▄▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄▄▄ ▐░▌          ▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄▄▄      ▐░▌     
▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌          ▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌     ▐░▌     
 ▀▀▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░▌          ▐░█▀▀▀▀█░█▀▀ ▐░█▀▀▀▀▀▀▀▀▀      ▐░▌     
          ▐░▌▐░▌          ▐░▌          ▐░▌     ▐░▌  ▐░▌               ▐░▌     
 ▄▄▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄▄▄ ▐░▌      ▐░▌ ▐░█▄▄▄▄▄▄▄▄▄      ▐░▌     
▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌     ▐░▌     
 ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀       ▀      
                                                                              
 ▄         ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄        ▄ 
▐░▌       ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░▌      ▐░▌
▐░▌       ▐░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌░▌     ▐░▌
▐░▌       ▐░▌▐░▌          ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌       ▐░▌▐░▌▐░▌    ▐░▌
▐░▌   ▄   ▐░▌▐░█▄▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░▌ ▐░▌   ▐░▌
▐░▌  ▐░▌  ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░▌  ▐░▌  ▐░▌
▐░▌ ▐░▌░▌ ▐░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░▌       ▐░▌▐░▌   ▐░▌ ▐░▌
▐░▌▐░▌ ▐░▌▐░▌▐░▌          ▐░▌       ▐░▌▐░▌          ▐░▌       ▐░▌▐░▌    ▐░▌▐░▌
▐░▌░▌   ▐░▐░▌▐░█▄▄▄▄▄▄▄▄▄ ▐░▌       ▐░▌▐░▌          ▐░█▄▄▄▄▄▄▄█░▌▐░▌     ▐░▐░▌
▐░░▌     ▐░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░▌          ▐░░░░░░░░░░░▌▐░▌      ▐░░▌
 ▀▀       ▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀            ▀▀▀▀▀▀▀▀▀▀▀  ▀        ▀▀ 
                                                                              
       
       
       
    \033[0m  """)
    print("Welcome to Secret Weapon!")
    print("Find and destroy the secret weapon before it destroys you!")
    print("if you find the secret weapon you will cripple the robot army.")

    time.sleep(4)
    os.system('cls||clear')
    
def secret_weapon_game():
    
    difficulty = int(input("Enter difficulty level 1-5: "))

    if difficulty < 1 or difficulty > 5:
        print("Invalid difficulty level. Please enter a number between 1 and 5.")
        return
    
    #creates a random location for the secret weapon based on the difficulty level
    if difficulty == 1:
        print("Easy: The secret weapon is very close to you.")
        secret_weapon_x = random.randint(1, 5)
        secret_weapon_y = random.randint(1, 5)
        secret_weapon_range = 5
    elif difficulty == 2:
        print("Medium: The secret weapon is somewhat close to you.")
        secret_weapon_x = random.randint(1, 10)
        secret_weapon_y = random.randint(1, 10)
        secret_weapon_range = 10
    elif difficulty == 3:
        print("Hard: The secret weapon is moderately far from you.")
        secret_weapon_x = random.randint(1, 15)
        secret_weapon_y = random.randint(1, 15)
        secret_weapon_range = 15
    elif difficulty == 4:
        print("Very Hard: The secret weapon is quite far from you.")
        secret_weapon_x = random.randint(1, 20)
        secret_weapon_y = random.randint(1, 20)
        secret_weapon_range = 20

    else:
        print("Extremely Hard: The secret weapon is very far from you.")
        secret_weapon_x = random.randint(1, 30)
        secret_weapon_y = random.randint(1, 30)
        secret_weapon_range = 30
    
    tries = 0 
    for tries in range(5):
        tries += 1
        print(f"enter the coordinates of the secret weapon (x,y) between 1 and {secret_weapon_range}")
        x = int(input("x: "))
        y = int(input("y: "))
        
        #calcualte the distance from the player's guess to the secret weapon using the Manhattan distance formula
        z = abs(secret_weapon_x - x) + abs(secret_weapon_y - y)
        
        #if the player's guess is correct, they win. If the distance is less than or equal to the difficulty level, they are getting warmer. If the distance is greater than the difficulty level, they are getting colder.
        if z == 0:
            print("You found the secret weapon! You win!")
            break
        elif z <= difficulty:
            print("You're getting warmer!")
        else:
            print("You're getting colder!")
        
        #if the number tries reaches 5, the player loses and the location of the secret weapon is revealed
        if tries == 5:
            print(f"You've used all your tries! The secret weapon was at ({secret_weapon_x}, {secret_weapon_y}). You lose!")
          
if __name__ == "__main__":
    # intro_function_here()
    secret_weapon_intro()
    while True:
        # game_function_here()  
        secret_weapon_game()
        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break