import time
import os
import random
import main_menu

def shootout_intro():
    print(r"""
          
   ▄████████    ▄█    █▄     ▄██████▄   ▄██████▄      ███      ▄██████▄  ███    █▄      ███     
  ███    ███   ███    ███   ███    ███ ███    ███ ▀█████████▄ ███    ███ ███    ███ ▀█████████▄ 
  ███    █▀    ███    ███   ███    ███ ███    ███    ▀███▀▀██ ███    ███ ███    ███    ▀███▀▀██ 
  ███         ▄███▄▄▄▄███▄▄ ███    ███ ███    ███     ███   ▀ ███    ███ ███    ███     ███   ▀ 
▀███████████ ▀▀███▀▀▀▀███▀  ███    ███ ███    ███     ███     ███    ███ ███    ███     ███     
         ███   ███    ███   ███    ███ ███    ███     ███     ███    ███ ███    ███     ███     
   ▄█    ███   ███    ███   ███    ███ ███    ███     ███     ███    ███ ███    ███     ███     
 ▄████████▀    ███    █▀     ▀██████▀   ▀██████▀     ▄████▀    ▀██████▀  ████████▀     ▄████▀   
                                                                                               
          
          """)
    time.sleep(2)
    print("Get ready for the shootout!")
    time.sleep(2)

def shootout_game():
    os.system('cls||clear') #clears the screen before the game starts

    print("SHOOTOUT")
    print()

    time.sleep(2)

    print("You are in a shootout with a robot.")

    #the wait phase
    print("Get ready...")
    time.sleep(random.uniform(2, 5)) #waits a random amount of time between 2 and 5 seconds

    #the draw phase
    print("\n----DRAW!!!!----")
    start_time = time.time()
    input("Press [ENTER] to shoot: ")
    end_time = time.time()
    reaction_time = end_time - start_time
    
    #win/loss logic
    print(f"\nYour reaction time was {reaction_time:.2f} seconds.")
    if reaction_time <= 2.0: #if the player reacts in 2 seconds or less, they win
        print("You shot the robot in time! You win!")
    else:
        print("The robot shot you! You lose!")

    time.sleep(2)
    #os.system('cls||clear') #clears the screen after the game ends


if __name__ == "__main__":
    shootout_intro()
    while True:
        shootout_game()  
        
        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            exit
            
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            exit