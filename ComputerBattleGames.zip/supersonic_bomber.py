import os
import time
import random
import msvcrt  # Built-in Windows module for non-blocking key presses
import main_menu

def supersonic_bomber_intro():
    print(r""""
   ▄████████ ███    █▄     ▄███████▄    ▄████████    ▄████████    ▄████████  ▄██████▄  ███▄▄▄▄    ▄█   ▄████████ 
  ███    ███ ███    ███   ███    ███   ███    ███   ███    ███   ███    ███ ███    ███ ███▀▀▀██▄ ███  ███    ███ 
  ███    █▀  ███    ███   ███    ███   ███    █▀    ███    ███   ███    █▀  ███    ███ ███   ███ ███▌ ███    █▀  
  ███        ███    ███   ███    ███  ▄███▄▄▄      ▄███▄▄▄▄██▀   ███        ███    ███ ███   ███ ███▌ ███        
▀███████████ ███    ███ ▀█████████▀  ▀▀███▀▀▀     ▀▀███▀▀▀▀▀   ▀███████████ ███    ███ ███   ███ ███▌ ███        
         ███ ███    ███   ███          ███    █▄  ▀███████████          ███ ███    ███ ███   ███ ███  ███    █▄  
   ▄█    ███ ███    ███   ███          ███    ███   ███    ███    ▄█    ███ ███    ███ ███   ███ ███  ███    ███ 
 ▄████████▀  ████████▀   ▄████▀        ██████████   ███    ███  ▄████████▀   ▀██████▀   ▀█   █▀  █▀   ████████▀  
                                                    ███    ███                                                   
          ▀█████████▄   ▄██████▄    ▄▄▄▄███▄▄▄▄   ▀█████████▄     ▄████████    ▄████████                         
            ███    ███ ███    ███ ▄██▀▀▀███▀▀▀██▄   ███    ███   ███    ███   ███    ███                         
            ███    ███ ███    ███ ███   ███   ███   ███    ███   ███    █▀    ███    ███                         
           ▄███▄▄▄██▀  ███    ███ ███   ███   ███  ▄███▄▄▄██▀   ▄███▄▄▄      ▄███▄▄▄▄██▀                         
          ▀▀███▀▀▀██▄  ███    ███ ███   ███   ███ ▀▀███▀▀▀██▄  ▀▀███▀▀▀     ▀▀███▀▀▀▀▀                           
            ███    ██▄ ███    ███ ███   ███   ███   ███    ██▄   ███    █▄  ▀███████████                         
            ███    ███ ███    ███ ███   ███   ███   ███    ███   ███    ███   ███    ███                         
          ▄█████████▀   ▀██████▀   ▀█   ███   █▀  ▄█████████▀    ██████████   ███    ███                         
                                                                              ███    ███                                                                                                   
    """)

    time.sleep(2)

    print("""You are on a lone supersonic bombing mission over the U.R.S. 
    Your computer shows data of Robot populations relayed by satellite.
    You only have time to attack one target in five, so you must quickly 
    select the one with the highest population of Robots.
    
    ⚠️ RULES:
    1. You only have 3 SECONDS to enter a target number before the bomb auto-drops!
    2. If two populations are identical, you MUST choose the lower target number!""")

    time.sleep(5)
    os.system('cls' if os.name == 'nt' else 'clear')
    
def supersonic_bomber_game():
    print("\nInitializing bombing run...")
    time.sleep(3)

    score = 0
    bombing_runs = 10

    while bombing_runs > 0:
        os.system('cls' if os.name == 'nt' else 'clear')
        
        targets = [random.randint(10, 100) for _ in range(5)]
        
        # Enforce tie-breaker rule: find the true optimal target index (1-indexed)
        # .index() naturally returns the FIRST (lowest numbered) occurrence of the max value
        correct_choice = targets.index(max(targets)) + 1
        highest_population = targets[correct_choice - 1]
        
        print("=" * 40)
        print(f" MISSION STATUS: {bombing_runs} RUNS REMAINING ")
        print(f" CURRENT SCORE:  {score} / 10")
        print("=" * 40)
        print("\nDetecting Robot Populations...")
        for i, target in enumerate(targets, start=1):
            print(f" -> Target {i}: {target} Robots")
        print("-" * 40)
        print("⚡ BOMB LOCK ACTIVE! YOU HAVE 3 SECONDS TO CHOOSE! ⚡")
        print("Enter target number (1-5): ", end="", flush=True)

        # --- CROSS-PLATFORM NON-BLOCKING TIMER (WINDOWS) ---
        start_time = time.time()
        player_input = ""
        timed_out = False

        while True:
            # Check if 5 seconds have passed
            if time.time() - start_time > 5.0:
                timed_out = True
                break
            
            # Check if a key has been pressed
            if msvcrt.kbhit():
                char = msvcrt.getche().decode('utf-8') # Grab the keypress and echo it
                if char in ['1', '2', '3', '4', '5']:
                    player_input = char
                    break
                elif char in ['\r', '\n']: # Ignore early enters
                    continue
                else:
                    print("\n❌ Invalid key! Use numbers 1-5.")
                    player_input = "invalid"
                    break
                    
            time.sleep(0.05) # Tiny sleep to avoid maximizing CPU usage

        print() # Move to next line after input or timeout

        # --- EVALUATE TURN ---
        if timed_out:
            print("\n⏰ TIME EXPIRED! The computer panicked and dropped the bomb randomly!")
            player_choice = random.randint(1, 5)
            time.sleep(1.5)
        elif player_input == "invalid" or not player_input:
            player_choice = -1 # Triggers the miss condition smoothly
        else:
            player_choice = int(player_input)

        if player_choice == correct_choice:
            print(f"\n💥 DIRECT HIT! You destroyed Target {player_choice} holding {highest_population} robots!")
            score += 1
        else:
            if player_choice != -1:
                print(f"\n💨 MISSED! You targeted sector {player_choice}.")
            print(f"The tactical choice was Target {correct_choice} ({highest_population} robots).")
            if targets.count(max(targets)) > 1:
                print("💡 Remember the tie-breaker rule: Pick the lowest target number if populations match!")

        bombing_runs -= 1
        time.sleep(3.5)

    # --- END GAME ---
    os.system('cls' if os.name == 'nt' else 'clear')
    print("=" * 40)
    print("             MISSION COMPLETE           ")
    print("=" * 40)
    print(f"\nFinal Score: {score} out of 10.")

    if score >= 8:
        print("Excellent work, Commander! The robot uprising has been crushed.")
    elif score >= 5:
        print("Decent job, but tactical suggests you work on your targeting speed.")
    else:
        print("Mission failure. The robots overran the sector.")

if __name__ == "__main__":
    # intro_function_here()
    supersonic_bomber_intro()
    while True:
        # game_function_here()  
        supersonic_bomber_game()
        choice = input("\nPlay again? (y/n): ").strip().lower()
        
        if choice == 'n':
            print("Thanks for playing!")
            print("Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break
        elif choice != 'y':
            print("Invalid input. Returning to main menu...")
            time.sleep(2)
            main_menu.menu()
            break